.. _cross_decomposition_examples:

Cross decomposition
-------------------

Examples concerning the :mod:`sklearn.cross_decomposition` module.

